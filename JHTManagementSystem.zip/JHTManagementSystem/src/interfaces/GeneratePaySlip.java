package interfaces;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import databaseAction.GeneratePaySlipDatabaseAction;

public class GeneratePaySlip {
    private JFrame frame;
    private JPanel panel;
    private DefaultTableModel model;
    private GeneratePaySlipDatabaseAction paySlipAction;

    public GeneratePaySlip() {
        frame = new JFrame();
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        String[] columnNames = {"Pay Slip ID", "Start Date", "End Date", "Salary"};
        model = new DefaultTableModel(columnNames, 0);

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400, 150));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        panel.add(scrollPane, gbc);

        frame.add(panel, gbc);
        frame.setSize(520, 450);
        frame.setVisible(false);
    }

    public void getRecords(String staffID) {
        frame.setVisible(true);
        paySlipAction = new GeneratePaySlipDatabaseAction();
        ResultSet resultSet = paySlipAction.getPaySlipDetails(staffID);

        try {
            while (resultSet.next()) {
                String paySlipId = resultSet.getString("Pay Slip ID");
                String startDate = resultSet.getString("Start Date");
                String endDate = resultSet.getString("End Date");
                String salary = resultSet.getString("Salary");

                model.addRow(new Object[]{paySlipId, startDate, endDate, salary});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
