package interfaces;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import databaseAction.PaySlipDatabaseAction;

public class PaySlipJPanel {

    private JPanel panel;
    private JLabel headingLabel;
    private GridBagConstraints gbc;
    private DefaultTableModel model;
    private PaySlipDatabaseAction paySlipAction;
    public GeneratePaySlip generatePaySlip;

    public PaySlipJPanel() {
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        paySlipAction = new PaySlipDatabaseAction();

        headingLabel = new JLabel("Pay Slips");
        gbc.gridx = 0;
        gbc.gridy = 0;
        headingLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(headingLabel, gbc);

        String[] columnNames = {"Pay Slip ID", "Start Date", "End Date", "Salary", "View Pay Slip"};

        model = new DefaultTableModel(columnNames, 0);

        JTable table = new JTable(model);
        table.setFillsViewportHeight(true);

        ButtonRenderer buttonRenderer = new ButtonRenderer();
        ButtonEditor buttonEditor = new ButtonEditor(new JTextField());
        table.getColumnModel().getColumn(4).setCellRenderer(buttonRenderer);
        table.getColumnModel().getColumn(4).setCellEditor(buttonEditor);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(980, 400));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 5;
        panel.add(scrollPane, gbc);

        JButton viewAllButton = new JButton("View All");
        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        gbc.insets = new Insets(0, 20, 0, 0);
        viewAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setRowCount(0);
                addRecords(paySlipAction.getPaySlipDetails());
            }
        });

        panel.add(viewAllButton, gbc);

        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(new Dimension(1000, 600));
    }

    public JPanel getPanel() {
        return panel;
    }

    public void addRecords(ResultSet resultSet) {
        try {
            while (resultSet.next()) {
                String paySlipId = resultSet.getString("payId");
                String startDate = resultSet.getString("startDate");
                String endDate = resultSet.getString("endDate");
                String salary = resultSet.getString("salary");

                model.addRow(new Object[]{paySlipId, startDate, endDate, salary});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value != null) {
                setText(value.toString());
            } else {
                setText("View Pay Slip");
            }
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        JButton button;
        private String label = "View Pay Slip";
        private boolean isPushed;
        String staffID;
        String paySlipId;

        public ButtonEditor(JTextField textField) {
            super(textField);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (isSelected) {
                button.setForeground(table.getSelectionForeground());
                button.setBackground(table.getSelectionBackground());
            } else {
                button.setForeground(table.getForeground());
                button.setBackground(UIManager.getColor("Button.background"));
            }

            staffID = (String) table.getModel().getValueAt(row, 1);
            paySlipId = (String) table.getModel().getValueAt(row, 0);
            button.setText(label);
            isPushed = true;
            return button;
        }

        public Object getCellEditorValue() {
            if (isPushed) {
                generatePaySlip = new GeneratePaySlip();
                //checkback
                generatePaySlip.getRecords(staffID);
            }
            isPushed = false;
            return label;
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
}
