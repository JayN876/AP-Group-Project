package client;

import interfaces.AdminLogin;

public class Driver {
	
	public static void main(String[] args) {
		AdminLogin adminLogin = new AdminLogin();
	}
}
