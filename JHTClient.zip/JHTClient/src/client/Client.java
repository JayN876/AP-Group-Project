package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import javax.swing.JOptionPane;

import beans.CompanyRepresentative;
import beans.CreateDeliveryRequest;
import beans.DeliveryDriver;
import beans.DeliveryRoute;
import personalInfo.Customer;
import personalInfo.Driver;
import personalInfo.GenerateInvoiceDetails;
import personalInfo.InvoiceData;
import personalInfo.LoginInfo;
import personalInfo.OutstandingBalance;
import personalInfo.ReportData;
import personalInfo.RouteRate;
import personalInfo.Staff;
import personalInfo.StaffSalary;
import personalInfo.Transactions;

public class Client {
	
	private ObjectInputStream objIs;
	private static ObjectOutputStream objOs;
	private Socket connectionSocket;
	private String action="";
	
	public Client() {
		this.createConnection();
		this.configureStreams();
	}
	
	public void createConnection() {
		try {
			connectionSocket = new Socket("127.0.0.1",8888);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	private void configureStreams() {
		try {
			objIs = new ObjectInputStream(connectionSocket.getInputStream());
			objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void closeConnection() {
		try {
			objOs.close();
			objIs.close();
			connectionSocket.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public ObjectInputStream getObjectInputStream() {
	    return objIs;
	}

	public void sendAction(String action) {
		this.action=action;
		try {
			
			objOs.writeObject(action);
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	

	public void sendAdminLogin(LoginInfo loginInfo) {
		try {
			objOs.writeObject(loginInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void sendCustomer(Customer customer) {
		try {
			objOs.writeObject(customer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void sendAllID(String staffID, String adminID, String contractorID, String plateNum) {
		try {
		objOs.writeObject(staffID);
		objOs.writeObject(adminID);
		objOs.writeObject(contractorID);
		objOs.writeObject(plateNum);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void sendContractorDetails(String conID, String staffID) {
		try {
			objOs.writeObject(conID);
			objOs.writeObject(staffID);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	public void sendDriver(Driver driver) {
		try {
			objOs.writeObject(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void sendStaff(Staff staff) {
		try {
			objOs.writeObject(staff);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void sendMaintenanceDetails(String contractorID, String staffID, String selectedItem) {
		try {
			objOs.writeObject(contractorID);
			objOs.writeObject(staffID);
			objOs.writeObject(selectedItem);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void sendAdminDetails(String adminField, String staffID, String selectedItem) {
		try {
			objOs.writeObject(adminField);
			objOs.writeObject(staffID);
			objOs.writeObject(selectedItem);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void sendLoginDetails(String staffID, String password) {
		try {
			objOs.writeObject(staffID);
			objOs.writeObject(password);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void sendActionDetails(String staffAction, String adminID) {
		try {
			objOs.writeObject(staffAction);
			objOs.writeObject(adminID);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void sendRouteDetails(RouteRate routeRate) {
		try {
			objOs.writeObject(routeRate);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void sendReportDateRange(String startDate, String endDate) {
		
		try {
			objOs.writeObject(startDate);
			objOs.writeObject(endDate);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void sendInvoiceDetails(String cusID) {
		try {
			objOs.writeObject(cusID);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	public void sendInvoiceNo(String invoiceNo) {
		
		try {
			objOs.writeObject(invoiceNo);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

	public void sendCustomerID(String customerID) {
		try {
			objOs.writeObject(customerID);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void sendSlipDate(String startDate, String endDate) {
		try {
			objOs.writeObject(startDate);
			objOs.writeObject(endDate);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	public void sendPaySlipDetails(String staffID, String paySlipID) {
		try {
			objOs.writeObject(staffID);
			objOs.writeObject(paySlipID);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void sendDeliveryRequest(CreateDeliveryRequest deliveryRequest) {
		try {
			objOs.writeObject(deliveryRequest);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	@SuppressWarnings("unchecked")
	public Object recieveResponse() {
		
		try {
			if(action.equals("Verify login")) {
				Boolean verificationResult = (Boolean) objIs.readObject();
				return verificationResult;
			}
			
			else if(action.equals("Existing StaffIDs")) {
				return (Boolean) objIs.readObject();
			}
			else if(action.equals("Route Exist")) {
				return (Boolean) objIs.readObject();
			}
			else if(action.equals("Get Outstanding Customer")) {
				return (List<OutstandingBalance> )objIs.readObject();
			}
			else if(action.equals("Filter Report by Date")) {
				return (List<ReportData>)objIs.readObject();
			}
			else if(action.equals("Filter Report by Driver Name")) {
				return (List<ReportData>)objIs.readObject();
			}
			else if(action.equals("View All Drivers")) {

				return (List<ReportData>) objIs.readObject();
			}
			else if( action.equals("Filter Report by Driver ID")){
				return (List<ReportData>) objIs.readObject();
			}
			else if(action.equals("Search Invoice by CusID")) {

				return (List<InvoiceData>) objIs.readObject();
			}
			else if(action.equals("View All Invoice")) {
				return (List<InvoiceData>) objIs.readObject();
			}
			else if(action.equals("Generate Invoice")) {
				return (List <GenerateInvoiceDetails>)objIs.readObject();
				
			}else if(action.equals("Transaction Details Invoice")) {

				return (List <Transactions>)objIs.readObject();
			}
			else if(action.equals("View RateSheet")) {

				return (List<RouteRate>)objIs.readObject();
			}
			else if(action.equals("View all Pay slip Records")) {
				return (List <StaffSalary>)objIs.readObject();
			}
			else if(action.equals("Payslip by date Range")) {
				return (List <StaffSalary>)objIs.readObject();
			}
			else if(action.equals("Get PaySlip Record")) {
				return (List <StaffSalary>)objIs.readObject();
			}
			else if(action.equals("Get All Customer Companies")) {
				return (List<CompanyRepresentative>)objIs.readObject();
			}
			else if(action.equals("Get All Delivery Routes")){
				return (List<DeliveryRoute>)objIs.readObject();
			}
			else if (action.equals("Get All Delivery Drivers")) {
				return (List<DeliveryDriver>)objIs.readObject();
			}
			else if (action.equals("Create Delivery Response")) {
				return (Boolean)objIs.readObject();
			}
			else if(action.equals("Get Admin loggedIn")) {
				return (String)objIs.readObject();
			}
			else {
				JOptionPane.showMessageDialog(null, "Invalid recieved by client","Client action Status",JOptionPane.ERROR_MESSAGE);
				
			}

		} catch (ClassCastException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return "Nothing";
	}

}
