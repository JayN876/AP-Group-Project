package personalInfo;

public class EmployeeSalary {
	
	private String payID;
	private String staffID;
	private String startDate;
	private String endDate;
	private double salary;
	private String billedBy;
	
	
	
	
	public EmployeeSalary(String payID, String staffID, String startDate, String endDate, double salary,
			String billedBy) {
		this.payID = payID;
		this.staffID = staffID;
		this.startDate = startDate;
		this.endDate = endDate;
		this.salary = salary;
		this.billedBy = billedBy;
	}
	
	public EmployeeSalary() {
		this.payID = "";
		this.staffID = "";
		this.startDate = "";
		this.endDate = "";
		this.salary = 0.0;
		this.billedBy = "";
	}
	
	public EmployeeSalary(EmployeeSalary employeeSalary) {
		this.payID = employeeSalary.payID;
		this.staffID = employeeSalary.staffID;
		this.startDate = employeeSalary.startDate;
		this.endDate = employeeSalary.endDate;
		this.salary = employeeSalary.salary;
		this.billedBy = employeeSalary.billedBy;
	}
	
	public String getPayID() {
		return payID;
	}
	public void setPayID(String payID) {
		this.payID = payID;
	}
	public String getStaffID() {
		return staffID;
	}
	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBilledBy() {
		return billedBy;
	}
	public void setBilledBy(String billedBy) {
		this.billedBy = billedBy;
	}
	
	
	
	
}
