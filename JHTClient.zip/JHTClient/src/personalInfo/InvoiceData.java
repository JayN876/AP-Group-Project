package personalInfo;

import java.io.Serializable;

public class InvoiceData implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String invoiceNo;
    private String sourceAddress;
    private String destinationAddress;
    private String company;
    private String customerId;
    private String billedBy;
    private String rate;

    // Constructor
    public InvoiceData(String invoiceNo, String sourceAddress, String destinationAddress, String company, String customerId, String billedBy, String rate) {
        this.invoiceNo = invoiceNo;
        this.sourceAddress = sourceAddress;
        this.destinationAddress = destinationAddress;
        this.company = company;
        this.customerId = customerId;
        this.billedBy = billedBy;
        this.rate = rate;
    }

    // Getters
    public String getInvoiceNo() {
        return invoiceNo;
    }

    public String getSourceAddress() {
        return sourceAddress;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public String getCompany() {
        return company;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getBilledBy() {
        return billedBy;
    }

    public String getRate() {
        return rate;
    }
}
