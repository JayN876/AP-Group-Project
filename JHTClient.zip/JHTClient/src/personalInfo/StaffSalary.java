package personalInfo;

import java.io.Serializable;

public class StaffSalary implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String payID;
	private String staffID;
	private String fName;
	private String startDate;
	private String endDate;
	private double salary;
	private String billedBy;
	
	
	public StaffSalary(String payID, String staffID, String startDate, String endDate, double salary,
			String billedBy) {
		this.payID = payID;
		this.staffID = staffID;
		this.startDate = startDate;
		this.endDate = endDate;
		this.salary = salary;
		this.billedBy = billedBy;
	}
	
	public StaffSalary(String payID, String staffID, String fName,String startDate, String endDate, double salary, String billedBy) {
		this.payID = payID;
		this.staffID = staffID;
		this.startDate = startDate;
		this.endDate = endDate;
		this.salary = salary;
		this.billedBy = billedBy;
		this.fName = fName;
	}
	
	public StaffSalary() {
		this.payID = "";
		this.staffID = "";
		this.startDate = "";
		this.endDate = "";
		this.salary = 0.0;
		this.billedBy = "";
	}
	
	public StaffSalary(StaffSalary employeeSalary) {
		this.payID = employeeSalary.payID;
		this.staffID = employeeSalary.staffID;
		this.startDate = employeeSalary.startDate;
		this.endDate = employeeSalary.endDate;
		this.salary = employeeSalary.salary;
		this.billedBy = employeeSalary.billedBy;
	}
	
	public String getPayID() {
		return payID;
	}
	public void setPayID(String payID) {
		this.payID = payID;
	}
	public String getStaffID() {
		return staffID;
	}
	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBilledBy() {
		return billedBy;
	}
	public void setBilledBy(String billedBy) {
		this.billedBy = billedBy;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}
		
	
}
