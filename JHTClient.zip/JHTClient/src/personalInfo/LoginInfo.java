package personalInfo;

import java.io.Serializable;

public class LoginInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	String staffID;
	String password;
	
	public LoginInfo(String staffID, String password) {
		this.staffID = staffID;
		this.password = password;
	}
	
	public LoginInfo() {
		this.staffID ="";
		this.password ="";
	}

	public String getStaffID() {
		return staffID;
	}

	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "LoginInfo [staffID=" + staffID + ", password=" + password + "]";
	}
	
	
	
	
}
