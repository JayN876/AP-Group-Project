package personalInfo;

import java.io.Serializable;

public class Maintenance extends Contractor implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String skillSet;

	public Maintenance(String staffID, String password,String firstName, String lastName, Date dob, Address address,
			String telephone, String email, String position, String status, String contratorID,
			String skillSetString) {
		super(staffID, password,firstName, lastName, dob, address, telephone, email, position, status, contratorID);
		this.skillSet = skillSetString;
	}
	
	
	public Maintenance() {
		super();
		this.skillSet = "";
	}
	
	public Maintenance(Staff staff,String contractorId ,String skillSet) {
		super(staff,contractorId);
		this.skillSet = skillSet;
	}


	public String getSkillSet() {
		return skillSet;
	}


	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}


	@Override
	public String toString() {
		return super.toString()+"\nMaintenance [skillSet=" + skillSet + "]";
	}
	
	
	
	
}
