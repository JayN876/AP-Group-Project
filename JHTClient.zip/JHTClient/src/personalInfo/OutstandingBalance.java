
package personalInfo;

import java.io.Serializable;

public class OutstandingBalance implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerId;
    private String routeID;
    private String customerName;
    private double totalPayment;
    private double rate;
    private String status;
    private double distance;

    public OutstandingBalance(String customerId, String customerName, double totalPayment, double rate, String status,double distance, String routeID) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.totalPayment = totalPayment;
        this.rate = rate;
        this.status = status;
        this.distance = distance;
        this.routeID = routeID;
    }
    
    public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(double totalPayment) {
		this.totalPayment = totalPayment;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public String getRouteID() {
		return routeID;
	}

	public void setRouteID(String routeID) {
		this.routeID = routeID;
	}

	@Override
	public String toString() {
		return "OutstandingBalance [customerId=" + customerId + ", routeID=" + routeID + ", customerName="
				+ customerName + ", totalPayment=" + totalPayment + ", rate=" + rate + ", status=" + status
				+ ", distance=" + distance + "]";
	}

	

}