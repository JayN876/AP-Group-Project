package personalInfo;

import java.io.Serializable;

public class ReportData implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String routeId;
    private String sourceAddress;
    private String destinationAddress;
    private String rate;
    private String staffId;
    private String driverName;
    private String dateOfTrip;

    
    
    public ReportData(String routeId, String sourceAddress, String destinationAddress, String rate, String staffId,
			String driverName, String dateOfTrip) {
		this.routeId = routeId;
		this.sourceAddress = sourceAddress;
		this.destinationAddress = destinationAddress;
		this.rate = rate;
		this.staffId = staffId;
		this.driverName = driverName;
		this.dateOfTrip = dateOfTrip;
	}

	public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getSourceAddress() {
        return sourceAddress;
    }

    public void setSourceAddress(String sourceAddress) {
        this.sourceAddress = sourceAddress;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDateOfTrip() {
        return dateOfTrip;
    }

    public void setDateOfTrip(String dateOfTrip) {
        this.dateOfTrip = dateOfTrip;
    }
}
