package personalInfo;

import java.io.Serializable;


public class GenerateInvoiceDetails implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sourceAddress;
    private String destinationAddress;
    private String customerId;
    private String customerName;
    private String orderId;
    private String billedBy;
    private String rate;
    private Double distance;
    
    // Constructor
    public GenerateInvoiceDetails(String sourceAddress, String destinationAddress, String customerId, String customerName, String orderId, String billedBy, String rate,Double distance) {
        this.sourceAddress = sourceAddress;
        this.destinationAddress = destinationAddress;
        this.customerId = customerId;
        this.customerName = customerName;
        this.orderId = orderId;
        this.billedBy = billedBy;
        this.rate = rate;
        this.distance = distance;
    }

    // Getters and setters
    public String getSourceAddress() {
        return sourceAddress;
    }

    public void setSourceAddress(String sourceAddress) {
        this.sourceAddress = sourceAddress;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getBilledBy() {
        return billedBy;
    }

    public void setBilledBy(String billedBy) {
        this.billedBy = billedBy;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}
    
    
}
