package interfaces;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.toedter.calendar.JCalendar;

import client.Client;
import personalInfo.ReportData;


public class ReportJPanel {
    

	private static final Logger logger = LogManager.getLogger(ReportJPanel.class);	
    private JPanel panel;
    private JTable table;
    private JLabel headingLabel;
    private GridBagConstraints gbc;
    private JLabel label;
    private DefaultTableModel model;
    private JButton startDateButton;
    private JButton endDateButton;
    private String startDateSelected;
    private String endDateSelected;
    private String actionString;
    private JLabel startDateLabel;
    private JLabel endDateLabel;
    private List<ReportData> reportDataList;
    public ReportJPanel() {
        

        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        
        headingLabel = new JLabel("Report");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 30)); // Set font size to 30
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(headingLabel, gbc);
        
        
        label = new JLabel("<html>Filters:<br>_________________________________________________________________________________________________________________________________________</html>");
        gbc.gridx=0;
        gbc.gridy=1;
        gbc.gridwidth=13;
        panel.add(label,gbc);
        
        gbc = new GridBagConstraints();  
        gbc.anchor = GridBagConstraints.NORTHWEST;
        startDateButton = new JButton("Start Period: ");
        gbc.gridx=0;
        gbc.gridy=2;
        gbc.gridwidth=2;
        startDateButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				new CalendarFrame();
				actionString = "Start";
			}
		});
        panel.add(startDateButton,gbc);
        
        gbc = new GridBagConstraints();  
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        startDateLabel = new JLabel("yyyy-mm-dd");
        gbc.gridx=1;
        gbc.gridy=2;
        gbc.insets = new Insets(0, -35, 0, 0);
        panel.add(startDateLabel,gbc);
        
        gbc = new GridBagConstraints();  
        gbc.anchor = GridBagConstraints.NORTHWEST;
        endDateButton = new JButton("End Period");
        gbc.gridx=2;
        gbc.gridy=2;
        gbc.gridwidth=2;
        gbc.insets = new Insets(0, 30, 0, 0);
        endDateButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				new CalendarFrame();
				actionString = "End";
			}
		});
        panel.add(endDateButton,gbc);
        
        gbc = new GridBagConstraints();  
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        endDateLabel = new JLabel("yyyy-mm-dd");
        gbc.gridx=3;
        gbc.gridy=2;
        gbc.insets = new Insets(0, -25, 0, 0);
        panel.add(endDateLabel,gbc);

        
        JButton goButton = new JButton("Filter by Date");
        gbc.gridx=4;
        gbc.insets = new Insets(0, 20, 0, 0);
        
        goButton.addActionListener(new ActionListener() {
            @SuppressWarnings("unchecked")
			@Override
            public void actionPerformed(ActionEvent e) {
                // Check if start date and end date fields are empty

                if (startDateLabel.getText().equals("yyyy-mm-dd")||endDateLabel.getText().equals("yyyy-mm-dd")) {
                	logger.info("Start date and end Date was not entered when filtering");
                    // Display JOptionPane with an error message if start date and end date  was not filled out
                    JOptionPane.showMessageDialog(null, "Please enter both start date and end date.", "Report Status", JOptionPane.ERROR_MESSAGE);
                } else {
                	model.setRowCount(0);
                    
                    Client reportClient = new Client();
                    reportClient.sendAction("Filter Report by Date");
                    reportClient.sendReportDateRange(startDateLabel.getText(),endDateLabel.getText());
                    
                	addRecords((List<ReportData>) reportClient.recieveResponse());
                }
            }
            
        });

        
        panel.add(goButton,gbc);
        
        JButton driverFilterButton = new JButton("Filter by Driver Name");
        gbc.gridx=0;
        gbc.gridy=3;
        gbc.insets = new Insets(10, 0, 10, 0);
        
        driverFilterButton.addActionListener(new ActionListener() {
			
			@SuppressWarnings("unchecked")
			@Override
			public void actionPerformed(ActionEvent e) {
				logger.info("Filter button clicked");
				model.setRowCount(0);
				Client reportClient = new Client();
				reportClient.sendAction("Filter Report by Driver Name");
				addRecords((List<ReportData> ) reportClient.recieveResponse());
			}
		});
        panel.add(driverFilterButton,gbc);
        
        gbc = new GridBagConstraints();
        JButton filterByDriverIDButton = new JButton("Filter by DriverID");
        gbc.gridx=2;
        gbc.gridy=3;
        gbc.insets = new Insets(10, 30,10, 0);
        filterByDriverIDButton.addActionListener(new ActionListener() {
			
			@SuppressWarnings("unchecked")
			@Override
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				Client reportClient = new Client();
				reportClient.sendAction("Filter Report by Driver ID");
			
				addRecords( (List<ReportData>) reportClient.recieveResponse());
				
			}
		});
        
        panel.add(filterByDriverIDButton,gbc);
        
        gbc = new GridBagConstraints();
        JButton viewAllButton = new JButton("View All");
        gbc.gridx=4;
        gbc.gridy=3;
        gbc.insets = new Insets(0, -5,0, 0);
        
        viewAllButton.addActionListener(new ActionListener() {
			
			@SuppressWarnings("unchecked")
			@Override
			public void actionPerformed(ActionEvent e) {
				logger.info("View all button clicked");
				model.setRowCount(0);
				Client reportClient = new Client();
				reportClient.sendAction("View All Drivers");		
				addRecords( (List<ReportData>) reportClient.recieveResponse());
				
			}
		});
        panel.add(viewAllButton,gbc);
        
        gbc = new GridBagConstraints();        
        String[] columnNames = {"RouteID", "Source", "Destination", "Driver-ID", "DriverName", "Date of Trip","Rate"};     
		
        client.Client reportClient = new Client();
        reportClient.sendAction("View All Drivers");
        reportDataList = (List<ReportData>) reportClient.recieveResponse();
               
        gbc.gridx=0;
        gbc.gridy=4;
        gbc.gridwidth=13;
      
        // Create table model
        model = new DefaultTableModel(columnNames,0);


        table = new JTable(model);
        
        // Set table model for the JTable
        table.setModel(model);
        
       
        addRecords(reportDataList);
        TableColumn column;
        
        for (int i = 0; i < table.getColumnCount(); i++) {
            column = table.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(13); // RouteID column width
            } else if (i == 1) {
                column.setPreferredWidth(230); // Source Address column width
            } else if (i == 2) {
                column.setPreferredWidth(230); // Destination Address column width
            } else {
            	column.setPreferredWidth(50);
            }
        }
        
        
        table.setFillsViewportHeight(true);
        // Create JScrollPane and add table to it
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(980, 400));
        
        // Add scroll pane to panel
        panel.add(scrollPane,gbc);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        panel.setPreferredSize(new Dimension(1000, 600));
        
    }
    
    public JPanel getPanel() {
		return panel;
	}
    
    
	public void addRecords(List<ReportData> reportDataList) {
	    try {
	        for (ReportData reportData : reportDataList) {
	            // Retrieve data from ReportData object
	            String routeID = reportData.getRouteId();
	            String source = reportData.getSourceAddress();
	            String destination = reportData.getDestinationAddress();
	            String staffID = reportData.getStaffId();
	            String driverName = reportData.getDriverName();
	            String dateOfTrip = reportData.getDateOfTrip();
	            String rate = reportData.getRate();
	            // Add record to the table model
	            model.addRow(new Object[]{routeID, source, destination, staffID, driverName, dateOfTrip, rate});
	        }
	        // Show JOptionPane to indicate successful addition
	        //JOptionPane.showMessageDialog(null, "Records added successfully", "Report Status", JOptionPane.INFORMATION_MESSAGE);
	    } catch (Exception e) {
	        e.printStackTrace();
	        // Show JOptionPane to indicate error
	        JOptionPane.showMessageDialog(null, "Error occurred while adding records", "Report Status", JOptionPane.ERROR_MESSAGE);
	    }
	}
	   

public class CalendarFrame {
    private JFrame frame;
    private JCalendar calendar;
    private JPanel panel;
    private JButton confirmButton;
    private GridBagConstraints gbc;

    public CalendarFrame() {
        frame = new JFrame();
        frame.setLayout(new GridBagLayout());
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        
        calendar = new JCalendar();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(calendar);
               
        confirmButton = new JButton("Confirm");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               	// Get the date from the calendar
                java.util.Date date = calendar.getDate();
                
                // Convert date to Calendar instance
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                
                // Get year, month, and day
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH) + 1; // Month is 0-based, so we add 1
                int day = cal.get(Calendar.DAY_OF_MONTH);
                
                // Format year, month, and day
                String formattedYear = String.format("%04d", year);
                String formattedMonth = String.format("%02d", month);
                String formattedDay = String.format("%02d", day);
                
                // Construct the date string in the desired format
                String formattedDate = formattedYear + "-" + formattedMonth + "-" + formattedDay;
                if(actionString.equals("Start")) {
	                startDateSelected = formattedDate;
	                startDateLabel.setText(formattedDate);
                }
                else if(actionString.equals("End")) {
	                endDateSelected = formattedDate;
	                endDateLabel.setText(formattedDate);
                }
                frame.dispose();
                
            }
        });

        panel.add(confirmButton,gbc);
        
        panel.setPreferredSize(new Dimension(300, 300));
        frame.add(panel,gbc);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        frame.setLocationRelativeTo(null); // Set the frame to appear at the center of the screen
        frame.setVisible(true);
       
    }
    
   
}

    
    public static void main(String[] args) {
        new ReportJPanel();
    }
    
}
