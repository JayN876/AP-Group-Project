package interfaces;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.Client;
import personalInfo.GenerateInvoiceDetails;
import personalInfo.Transactions;

public class GenerateInvoice {
	

	private static final Logger logger = LogManager.getLogger(GenerateInvoice.class);
    private JLabel receiptLabel;
    private JLabel sourceLabel;
    private JLabel destinationLabel;
    private JLabel cusIDLabel;
    private JLabel cusNameLabel;
    private JLabel orderIDLabel;
    private JLabel billedbyLabel;
    private JLabel rateLabel;
    private JLabel totalLabel;
    private JLabel outstandingLabel,totalDueLabel,distanceLabel;
    
    private JFrame frame;
    private GridBagConstraints gbc;
    private JPanel panel;
    private  DefaultTableModel model;
    private double totalPayment=0;
    
    public GenerateInvoice() {
    	
    	frame = new JFrame();
    	panel =  new JPanel();
    	panel.setLayout(new GridBagLayout());
    	frame.setLayout(new GridBagLayout());
    	gbc = new GridBagConstraints(); 
    	
    	
    	receiptLabel = new JLabel("Invoice");
    	Font labelFont = receiptLabel.getFont();
    	receiptLabel.setFont(new Font(labelFont.getName(), Font.BOLD, 30)); // Set font size to 30 and make it bold
    	gbc.gridx = 0;
    	gbc.gridy = 0;
    	gbc.gridwidth = 5;
    	gbc.anchor = GridBagConstraints.NORTHWEST;
    	gbc.insets = new Insets(-50, 0, 10, 0);
    	panel.add(receiptLabel, gbc);

    	
    	gbc.insets = new Insets(0, 0, 0, 0);
    	sourceLabel =new JLabel("Source : ");
    	gbc.gridx=0;
    	gbc.gridy=1;
    	gbc.gridwidth=5;
    	gbc.anchor = GridBagConstraints.NORTHWEST;
    	panel.add(sourceLabel,gbc);
    	
    	destinationLabel =new JLabel("Destination : ");
    	gbc.gridx=0;
    	gbc.gridy=2;
    	panel.add(destinationLabel,gbc);
    	
    	cusIDLabel =new JLabel("Customer ID: ");
    	gbc.gridx=0;
    	gbc.gridy=3;
    	panel.add(cusIDLabel,gbc);
    	
    	cusNameLabel =new JLabel("Customer Name : ");
    	gbc.gridx=0;
    	gbc.gridy=4;
    	panel.add(cusNameLabel,gbc);
    	
    	
    	orderIDLabel =new JLabel("Order ID : ");
    	gbc.gridx=0;
    	gbc.gridy=5;
    	panel.add(orderIDLabel,gbc);
    	
    	billedbyLabel =new JLabel("Billed by : ");
    	gbc.gridx=0;
    	gbc.gridy=6;
    	panel.add(billedbyLabel,gbc);
    	
    	receiptLabel =new JLabel("<html>__________________________________________________________<br><br></html>");
    	gbc.gridx=0;
    	gbc.gridy=7;
    	gbc.gridwidth=5;
    	panel.add(receiptLabel,gbc);
    	
    	
    	gbc= new GridBagConstraints();
    	gbc.gridx=0;
    	gbc.gridy=8;
    	gbc.gridwidth=4;
    	
    	String[] columnNames= {"Transaction No", "Date","Payment"};
        model = new DefaultTableModel( columnNames,0);
        
        // Create a JTable with the DefaultTableModel
        JTable table = new JTable(model);
    	
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400, 150));
        panel.add(scrollPane,gbc);
        
        gbc= new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
    	totalLabel =new JLabel("Total Payment : ");
    	gbc.gridx=0;
    	gbc.gridy=9;
    	panel.add(totalLabel,gbc);
    	

    	rateLabel =new JLabel("Rate : ");
    	gbc.gridx=0;
    	gbc.gridy++;
    	panel.add(rateLabel,gbc);
    	
    	distanceLabel = new JLabel ("Distance");
    	gbc.gridx=0;
    	gbc.gridy++;
    	panel.add(distanceLabel,gbc);
    	
    	totalDueLabel = new JLabel ("Total Due");
    	gbc.gridx=0;
    	gbc.gridy++;
    	panel.add(totalDueLabel,gbc);
    	
    	outstandingLabel =new JLabel("Outstanding Balance : ");
    	gbc.gridx=0;
    	gbc.gridy++;
    	panel.add(outstandingLabel,gbc);
    	
		panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		panel.setPreferredSize(new Dimension(450, 450));
    	frame.add(panel,gbc);
    	frame.setSize(520, 500);
    	frame.setVisible(false);//prevent window from displaying when being initialized
        
    }
    
public GenerateInvoice getRecords(String cusID, String InvoiceNo) {
    frame.setVisible(true); // display window when records are being retrieved

    Client generateInvoiceAction = new Client();
    generateInvoiceAction.sendAction("Generate Invoice");
    generateInvoiceAction.sendInvoiceDetails(cusID);

    @SuppressWarnings("unchecked")
    List<GenerateInvoiceDetails> genInvList = (List<GenerateInvoiceDetails>) generateInvoiceAction.recieveResponse();

    try {
        if (genInvList.isEmpty()) {
            logger.info("No Invoice Records Found");
            JOptionPane.showMessageDialog(null, "No Records Found", "Invoice Records Status", JOptionPane.INFORMATION_MESSAGE);
        } else {
            for (GenerateInvoiceDetails details : genInvList) {
                // Retrieve data from GenerateInvoiceDetails object
                String sourceAdd = details.getSourceAddress();
                String destinationAdd = details.getDestinationAddress();
                String customerId = details.getCustomerId();
                String customerName = details.getCustomerName();
                String orderID = details.getOrderId();
                String billedBy = details.getBilledBy();
                String rate = details.getRate();
                Double distanceDouble = details.getDistance();
                
                // Update UI components with retrieved data
                sourceLabel.setText("Source Address : " + sourceAdd);
                destinationLabel.setText("Destination Address : " + destinationAdd);
                cusIDLabel.setText("Customer ID : " + customerId);
                cusNameLabel.setText("Customer Name : " + customerName);
                orderIDLabel.setText("Order ID : " + orderID);
                billedbyLabel.setText("Billed by : " + billedBy);
                rateLabel.setText("Rate : $" + rate);
                distanceLabel.setText("Distance (Km) : "+ distanceDouble);
                totalDueLabel.setText("Total Due:  $" + (distanceDouble* Double.parseDouble(rate)) );
                // Add transaction details
                addTransactionDetails(InvoiceNo, (distanceDouble* Double.parseDouble(rate)));
            }
        }
    } catch (Exception e) {
        logger.error("Exception Caught: " + e.getMessage());
        e.printStackTrace();
    }
    return null;
}

public void addTransactionDetails(String InvoiceNo, Double totalDue) {
    try {
        Client generateInvoiceAction = new Client();
        generateInvoiceAction.sendAction("Transaction Details Invoice");
        generateInvoiceAction.sendInvoiceNo(InvoiceNo);
        @SuppressWarnings("unchecked")
        List<Transactions> transactionList = (List<Transactions>) generateInvoiceAction.recieveResponse();

        double totalPayment = 0.0;

        if (transactionList.isEmpty()) {
            logger.info("No Transaction Records found");
            JOptionPane.showMessageDialog(null, "No Records Found", "Transaction Status", JOptionPane.INFORMATION_MESSAGE);
        } else {
            for (Transactions transaction : transactionList) {
                // Retrieve data from Transactions object
                String transactionNo = transaction.getTransactionNo();
                String transactionDate = transaction.getTranDateString();
                String payment = Double.toString( transaction.getPayment());
                totalPayment += Double.parseDouble(payment);

                // Add row to the table model
                model.addRow(new Object[]{transactionNo, transactionDate, payment});
            }

            // Update total and outstanding balance labels
            totalLabel.setText("Total Payments: " + String.valueOf(totalPayment));
            outstandingLabel.setText("Outstanding Balance : " + (totalDue- totalPayment));
        }
    } catch (Exception e) {
        logger.error("Exception Occurred: " + e.getMessage());
        e.printStackTrace();
    }
}

	
    
}
