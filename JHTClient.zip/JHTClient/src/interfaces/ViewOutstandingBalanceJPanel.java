package interfaces;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import personalInfo.OutstandingBalance;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.Client;

public class ViewOutstandingBalanceJPanel {
	

	private static final Logger logger = LogManager.getLogger(ViewOutstandingBalanceJPanel.class);
    private JPanel panel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel headingLabel;
    private GridBagConstraints gbc;
    
    public ViewOutstandingBalanceJPanel() {
        panel = new JPanel(new GridBagLayout());
        initializePanel();
        populateTable();
    }

    private void populateTable() {
        tableModel.setRowCount(0);
        Client outstandingClient = new Client();
        outstandingClient.sendAction("Get Outstanding Customer");
        
        @SuppressWarnings("unchecked")
		List<OutstandingBalance> outstandingBalances = (List<OutstandingBalance>) outstandingClient.recieveResponse();
        Double totalDue=0.0;
        if (outstandingBalances != null) {
            for (OutstandingBalance balance : outstandingBalances) {
            	totalDue = balance.getRate() * balance.getDistance();
                Object[] rowData = {
                        balance.getCustomerId(),
                        balance.getCustomerName(),
                        balance.getRouteID(),
                        balance.getRate(),
                        balance.getTotalPayment(),                       
                        totalDue,
                        totalDue - balance.getTotalPayment(),             
                        balance.getStatus()
                };
                tableModel.addRow(rowData);
            }
        } else {
        	logger.error("Error fetching outstanding balances");
            JOptionPane.showMessageDialog(panel, "Error fetching outstanding balances", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initializePanel() {
    	
    	gbc= new GridBagConstraints();
    	gbc.gridx=0;
    	gbc.gridy=0;
    	gbc.anchor=GridBagConstraints.NORTHWEST;
        headingLabel = new JLabel("Customer with Outstanding Balance");
		Font font =  headingLabel.getFont();	
		headingLabel.setFont(new Font(font.getFontName(), font.getStyle(), 30));
		panel.add(headingLabel, gbc);
		
        String[] columnNames = {"Customer ID", "Customer Name","RouteID" ,"Rate","Payment Made","Total Due", "Outstanding Balance","Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        gbc.gridx=0;
        gbc.gridy=1;	
        scrollPane.setPreferredSize(new Dimension(780, 450));
        panel.add(scrollPane, gbc);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(new Dimension(800, 600));
    }

    public JPanel getPanel() {
        return panel;
    }
}